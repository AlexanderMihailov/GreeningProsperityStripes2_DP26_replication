%% ExcelTableConversion_ExactMatch_MATLABGemini_AM260316.m
%  AM260316

%% MATLAB: Greening Prosperity Stripes 2 - Consumption-Based Refinement
clear; clc;

% 1. READ TEMPLATE (Exactly 266 data rows)
% We set 'VariableNamingRule' to 'preserve' to stop the warning you saw.
templateFile = 'API_NE.CON.PRVT.PP.KD_DS2_en_excel_v2_5530.xls';
optsT = spreadsheetImportOptions('NumVariables', 2);
optsT.Sheet = 'Data';
optsT.DataRange = 'A5:B270';
optsT.VariableNamesRange = 'A4:B4';
optsT.VariableNamingRule = 'preserve'; 
masterList = readtable(templateFile, optsT);

% Rename internally for logic, but we will write the "Real" names to Excel later
masterList.Properties.VariableNames = {'CName', 'CCode'};

% 2. READ & PIVOT CO2 DATA
co2File = 'consumption-co2-per-capita.csv';
optsC = detectImportOptions(co2File, 'VariableNamingRule', 'preserve');
co2Raw = readtable(co2File, optsC);
valColName = co2Raw.Properties.VariableNames{4}; 

% Clean: Remove rows with no code and drop duplicates
co2Raw(ismissing(co2Raw.Code), :) = [];
[~, idx] = unique(co2Raw(:, {'Code', 'Year'}), 'rows', 'stable');
co2Clean = co2Raw(idx, {'Code', 'Year', valColName}); % Only keep 3 cols to ensure join works

% Pivot (Long to Wide)
co2Wide = unstack(co2Clean, valColName, 'Year');
co2Wide.Properties.VariableNames{'Code'} = 'CCode'; % Set key to match master

% 3. JOIN
finalTable = outerjoin(masterList, co2Wide, 'Keys', 'CCode', 'MergeKeys', true, 'Type', 'left');

% 4. METADATA & REORDERING
finalTable.IName(:) = "Per capita consumption-based CO2 emissions";
finalTable.ICode(:) = "CO2.CONS.PC";

% Column Indices: 1=Name, 2=Code, end-1=IndName, end=IndCode, middle=Years
yStart = 3; 
yEnd = width(finalTable) - 2;
iNameIdx = width(finalTable) - 1;
iCodeIdx = width(finalTable);

finalTable = finalTable(:, [1, 2, iNameIdx, iCodeIdx, yStart:yEnd]);

% 5. EXPORT WITH ROBUST CLEANING
outputFile = 'CO2pcConsBased_ExcelTableConversion_ExactMatch_MATLABGemini_AM260316.xlsx';

% Prepare Headers
yearNames = strrep(finalTable.Properties.VariableNames(5:end), 'x', '');
allHeaders = [{'Country Name', 'Country Code', 'Indicator Name', 'Indicator Code'}, yearNames];

% Write Metadata
meta = {'Data Source', 'World Development Indicators'; ...
        'Last Updated Date', char(datetime('today', 'Format', 'yyyy-MM-dd'))};
writecell(meta, outputFile, 'Sheet', 'Data', 'Range', 'A1');
writecell(allHeaders, outputFile, 'Sheet', 'Data', 'Range', 'A4');

% Convert to cell and use the ROBUST CLEANER
dataCell = table2cell(finalTable);

% FIX: This loop replaces the problematic cellfun logic
for i = 1:numel(dataCell)
    if ismissing(dataCell{i})
        dataCell{i} = ''; % Replace NaNs or missing strings with empty Excel cells
    end
end

writecell(dataCell, outputFile, 'Sheet', 'Data', 'Range', 'A5');

fprintf('Success! MATLAB file created with 266 countries and full consumption-based CO2 pc data.\n');