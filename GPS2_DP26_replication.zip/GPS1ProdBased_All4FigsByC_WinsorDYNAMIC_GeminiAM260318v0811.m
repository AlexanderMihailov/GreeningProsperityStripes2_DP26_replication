%% Greening Prosperity Stripes 1 (Production-Based) - Final Loop (All Countries and Regions)
%
% AM260318 Winsorization in this code is DYNAMIC (as in the parallel code for SummaryFigureOnly: Dynamic=PDMinMaxWorld) 
% AM260318 Winsorization in an alternative of this code is STATIC (as in the parallel code for SummaryFigureOnly: static=MinMax2020) 
%
% GPS1ProdBased_All4FigsByC_WinsorDYNAMIC_GeminiAM260318v0811.m
% AM260728 Modify the file name so that its length is not more than 63 characters!
% AM260811 Modified to handle missing data (NaN): empty/missing data years are rendered as 
%          white/blank space via AlphaData transparency mapping.
%
% Note that the code calculates the stripes over a predefined range of years
% 1990-2020 (see the years command below) - so modify for other ranges all relevant code!
%
% First created/executed: 18 March 2026, by Alexander Mihailov; run on MATLAB R2025b, MacBook Pro (November 2024),
%                                                               chip: Apple M4 Max, memory: 36GB, MacOS Tahoe, 26.5.1
% Last modified/executed: 11 August 2026, by Alexander Mihailov; run on MATLAB R2025b, MacBook Pro (November 2024),
%                                                               chip: Apple M4 Max, memory: 36GB, MacOS Tahoe, 26.5.1
% Prompts and interactions with Gemini (modes Pro and Thinking), free version, is acknowledged

clear; clc; close all;

diary GPS1ProdBased_All4FigsByC_WinsorDYNAMIC_GeminiAM260318v0811.txt % create a diary
                           % log (*.txt) file saving the output from the command window
tic                        % start stopwatch timer
t = datetime('now')        % return a datetime scalar representing the current date and time

% --- 1. COLOR PALETTES (4-Digit Precision) ---
wscolors_BlueToRed = [ ...
    0.0314 0.1882 0.4196; 0.0314 0.3176 0.6118; 0.1294 0.4431 0.7098; 0.2588 0.5725 0.7765; ...
    0.4196 0.6824 0.8392; 0.6196 0.7922 0.8824; 0.7765 0.8588 0.9373; 0.8706 0.9216 0.9686; ...
    0.9961 0.8784 0.8235; 0.9882 0.7333 0.6314; 0.9882 0.5725 0.4471; 0.9843 0.4157 0.2902; ...
    0.9373 0.2314 0.1725; 0.7961 0.0941 0.1137; 0.6471 0.0588 0.0824; 0.4039 0.0000 0.0510];

wscolors_BrownToGreen = [ ...
    0.5490 0.2745 0.0784; 0.6667 0.3529 0.1569; 0.7843 0.4314 0.2353; 0.8235 0.5098 0.3137; ...
    0.8627 0.5882 0.3922; 0.9020 0.6667 0.5490; 0.9412 0.7843 0.7843; 0.9922 0.9608 0.9020; ...
    0.9412 1.0000 0.8627; 0.7647 0.9804 0.6275; 0.6667 0.9412 0.5882; 0.5490 0.8824 0.5490; ...
    0.4706 0.8235 0.4706; 0.2353 0.6667 0.3922; 0.1176 0.5294 0.1961; 0.0000 0.3922 0.0000];

wscolors_GreenToBrown = flipud(wscolors_BrownToGreen);

% --- 2. SETUP OUTPUT DIRECTORY ---
outDir = 'Stripes1Prod_DYNAMIC_Global_AllColorbars_1990_2020';
if ~exist(outDir, 'dir'), mkdir(outDir); end

% --- 3. DATA LOADING ---
RGDPFile = 'API_NY.GDP.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx';
co2prodFile  = 'API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx';

fprintf('Loading Data... Ensure Excel files are closed!\n');
codes = readvars(RGDPFile, 'Sheet', 'Data', 'Range', 'B5:B270');
names = readvars(RGDPFile, 'Sheet', 'Data', 'Range', 'A5:A270');
%AM260729 Note that in the next 2 lines of code the Excel range needs to be
%         redefined any time the years of range/calculation are modified! 
dataMatrix_RGDP = readmatrix(RGDPFile, 'Sheet', 'Data', 'Range', 'AI5:BM270');
dataMatrix_CO2prod  = readmatrix(co2prodFile,  'Sheet', 'Data', 'Range', 'AI5:BM270');

years = 1990:2020;
numItems = length(codes);

all_C = dataMatrix_RGDP(~isnan(dataMatrix_RGDP));
all_E = dataMatrix_CO2prod(~isnan(dataMatrix_CO2prod));
all_G = dataMatrix_RGDP ./ dataMatrix_CO2prod; 
all_G = all_G(~isnan(all_G) & ~isinf(all_G));

%Dynamic winsorization bounds at 5% and 95%
bounds_RGDP = [prctile(all_C, 5), prctile(all_C, 95)];
bounds_CO2prod  = [prctile(all_E, 5), prctile(all_E, 95)];
bounds_GPR1prod  = [prctile(all_G, 5), prctile(all_G, 95)];

% --- 4. THE LOOP ---
for i = 1:numItems
    isoCode = char(codes(i));
    displayName = char(names(i));
    if isempty(isoCode) || all(isnan(isoCode)), continue; end
    
    fprintf('Processing [%d/%d]: %s (%s)\n', i, numItems, isoCode, displayName);
    
    vec_RGDP = dataMatrix_RGDP(i, :);
    vec_CO2prod  = dataMatrix_CO2prod(i, :);
    % Compute ratio (GPS1 = Real GDP / Production-based CO2)
    vec_GPR1prod = vec_RGDP ./ vec_CO2prod;
    % ANNOTATION: Ensure any non-finite values (Inf, -Inf, or NaN resulting from 
    % division by zero or missing inputs) are strictly converted to NaN.
    vec_GPR1prod(~isfinite(vec_GPR1prod)) = NaN; 
    
    basePath = fullfile(outDir, isoCode);

    draw_and_save(vec_RGDP, years, bounds_RGDP, wscolors_BlueToRed, ...
        [isoCode ': Real GDP pc, at constant PPP-USD of 2017, dynamic winsorization (1990-2020)'], [basePath '_1_RealGDPpc_DYNwin_1990_2020']);
    draw_and_save(vec_CO2prod, years, bounds_CO2prod, wscolors_GreenToBrown, ...
        [isoCode ': Production-Based CO2 Emissions pc, in metric tons, dynamic winsorization (1990-2020)'], [basePath '_2_ProdBasedCO2pc_DYNwin_1990_2020']);
    draw_and_save(vec_GPR1prod, years, bounds_GPR1prod, wscolors_BrownToGreen, ...
        [isoCode ': GPS 1, at discounted constant PPP-USD of 2017, dynamic winsorization (1990-2020)'], [basePath '_3_GPS1ProdBased_DYNwin_1990_2020']);
    
    % Summary Figure (Slightly wider to accommodate colorbars)
    fSum = figure('Color','w','Position', [100 100 1050 850], 'Visible', 'off');
    
    s1 = subplot(3,1,1); format_sub(vec_RGDP, years, bounds_RGDP, wscolors_BlueToRed, 'Real GDP pc, at constant PPP-USD of 2017, dynamic winsorization (1990-2020)');
    s2 = subplot(3,1,2); format_sub(vec_CO2prod,  years, bounds_CO2prod,  wscolors_GreenToBrown, 'Production-Based CO2 pc, in metric tons, dynamic winsorization (1990-2020)');
    s3 = subplot(3,1,3); format_sub(vec_GPR1prod,  years, bounds_GPR1prod,  wscolors_BrownToGreen, 'Greening prosperity stripes 1, at discounted constant PPP-USD of 2017, dynamic winsorization (1990-2020)');
    
    s1.Toolbar.Visible = 'off'; s2.Toolbar.Visible = 'off'; s3.Toolbar.Visible = 'off';
    sgtitle([displayName ' (' isoCode ') - Summary of Stripes'], 'FontWeight','bold');
    
    saveas(fSum, [basePath '_4_SummaryStripes1Prod_DYNwin_1990_2020.fig']);
    saveas(fSum, [basePath '_4_SummaryStripes1Prod_DYNwin_1990_2020.png']);
    saveas(fSum, [basePath '_4_SummaryStripes1Prod_DYNwin_1990_2020.epsc']);
    close(fSum);
    
    if mod(i, 20) == 0, drawnow; end 
end
fprintf('\nDone! All graphs saved in: %s\n', outDir);

toc         % stop the stopwatch timer and display the elapsed time
diary off   % close the diary log and save the text file

%% --- HELPER FUNCTIONS (WITH COLORBARS & TRANSPARENCY FOR MISSING DATA) ---
function draw_and_save(data, years, bounds, cmap, tit, fName)
    % Create a figure with a white background
    f = figure('Color','w','Position',[100 100 850 250],'Visible', 'off'); % Widened for scale
    ax = axes(f);

    % ANNOTATION: Force the axes background color to white ('w').
    % This guarantees that any pixel rendered as transparent (due to NaN/missing data)
    % will show as pure white/blank space rather than inheriting default gray axes color.
    set(ax, 'Color', 'w');
    
    % Duplicate the 1xN vector into a 2xN matrix so imagesc can render 2D stripes
    imgData = repmat(data, 2, 1);
    
    % ANNOTATION: Draw the image and capture the returned image handle (hIm).
    % MATLAB's imagesc by default assigns NaN values to the lowest index of the colormap.
    % To prevent NaN years from being rendered with an active color stripe:
    hIm = imagesc(ax, years, [0 1], imgData);
    
    % ANNOTATION: Set the AlphaData (transparency mask) property of the image object.
    % ~isnan(imgData) produces a logical matrix:
    %   - 1 (true) for valid numeric data  -> 100% opaque stripe (colored by colormap)
    %   - 0 (false) for NaN (missing data) -> 100% transparent stripe (shows white background)
    set(hIm, 'AlphaData', ~isnan(imgData));

    colormap(ax, cmap); clim(bounds);
    colorbar(ax, 'Location', 'eastoutside'); % ADDED RHS SCALE
    set(ax, 'YTick', [], 'XTick', years(1:1:end), 'FontSize', 9);
    ax.Toolbar.Visible = 'off'; 
    title(tit, 'FontWeight','bold');
    
    saveas(f, [fName '.fig']);
    saveas(f, [fName '.png']);
    saveas(f, [fName '.epsc']);
    close(f);
end

function format_sub(data, years, bounds, cmap, lbl)
    ax = gca;
    
    % ANNOTATION: Set axes background to white for subplot handling of missing data
    set(ax, 'Color', 'w');
    
    % Duplicate the 1xN vector into a 2xN matrix for imagesc
    imgData = repmat(data, 2, 1);
    
    % ANNOTATION: Render image and get graphic handle hIm
    hIm = imagesc(ax, years, [0 1], imgData);
    
    % ANNOTATION: Apply AlphaData transparency mask (~isnan) so missing data (NaN)
    % appears completely white/blank rather than mapped to colormap bounds.
    set(hIm, 'AlphaData', ~isnan(imgData));
    
    colormap(gca, cmap); clim(bounds);
    colorbar(gca, 'Location', 'eastoutside'); % ADDED RHS SCALE
    set(gca, 'YTick', [], 'XTick', years(1:1:end), 'FontSize', 8);
    title(lbl, 'FontWeight','bold');
end