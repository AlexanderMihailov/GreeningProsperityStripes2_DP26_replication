%% Greening Prosperity Stripes 2 (Consumption-Based) Stripes - Final Loop (All Countries and Regions)
%
% AM260318 Winsorization in this code is STATIC (as in the parallel code for SummaryFigureOnly: static=MinMax2020) 
% AM260318 Winsorization in an alternative of this code is DYNAMIC (as in the parallel code for SummaryFigureOnly: Dynamic=PDMinMaxWorld) 
%
% GPS2ConsBased_All4FigsByC_WinsorSTATIC2020_GeminiAM260318v0811.m
% AM260728 Modify the file name so that its length is not more than 63 characters!
% AM260811 Modified to handle missing data (NaN): empty/missing data years are rendered as 
%          white/blank space via AlphaData transparency mapping.
%
% Note that the code calculates the stripes over a predefined range of years
% 1990-2020 (see the years command below) - so modify for other ranges all relevant code!
%
% First created/executed: 18 March 2026, by Alexander Mihailov; run on MATLAB R2025b, MacBook Pro (November 2024),
%                                                               chip: Apple M4 Max, memory: 36GB, MacOS Tahoe, 26.5.1
% Last modified/executed: 11 August 2026, by Alexander Mihailov; run on MATLAB R2025b, MacBook Pro (November 2024),
%                                                               chip: Apple M4 Max, memory: 36GB, MacOS Tahoe, 26.5.1
% Prompts and interactions with Gemini (modes Pro and Flash - Extended Thinking), free version, is acknowledged

clear; clc; close all;

diary GPS2ConsBased_All4FigsByC_WinsorSTATIC2020_GeminiAM260318v0811.txt % create a diary
                           % log (*.txt) file saving the output from the command window
tic                        % start stopwatch timer
t = datetime('now')        % return a datetime scalar representing the current date and time

% --- 1. COLOR PALETTES (4-Digit Precision) ---
wscolors_BlueToRed = [ ...
    0.0314 0.1882 0.4196; 0.0314 0.3176 0.6118; 0.1294 0.4431 0.7098; 0.2588 0.5725 0.7765; ...
    0.4196 0.6824 0.8392; 0.6196 0.7922 0.8824; 0.7765 0.8588 0.9373; 0.8706 0.9216 0.9686; ...
    0.9961 0.8784 0.8235; 0.9882 0.7333 0.6314; 0.9882 0.5725 0.4471; 0.9843 0.4157 0.2902; ...
    0.9373 0.2314 0.1725; 0.7961 0.0941 0.1137; 0.6471 0.0588 0.0824; 0.4039 0.0000 0.0510];

wscolors_BrownToGreen = [ ...
    0.5490 0.2745 0.0784; 0.6667 0.3529 0.1569; 0.7843 0.4314 0.2353; 0.8235 0.5098 0.3137; ...
    0.8627 0.5882 0.3922; 0.9020 0.6667 0.5490; 0.9412 0.7843 0.7843; 0.9922 0.9608 0.9020; ...
    0.9412 1.0000 0.8627; 0.7647 0.9804 0.6275; 0.6667 0.9412 0.5882; 0.5490 0.8824 0.5490; ...
    0.4706 0.8235 0.4706; 0.2353 0.6667 0.3922; 0.1176 0.5294 0.1961; 0.0000 0.3922 0.0000];

wscolors_GreenToBrown = flipud(wscolors_BrownToGreen);

% --- 2. SETUP OUTPUT DIRECTORY ---
outDir = 'Stripes2Cons_STATIC_2020_AllColorbars_1990_2020';
if ~exist(outDir, 'dir'), mkdir(outDir); end

% --- 3. DATA LOADING ---
consFile = 'API_NE.CON.PRVT.PC.PP.KD_MATLAB.xlsx';
co2consFile  = 'ConsCO2pc_ExcelTableConversion_ExactMatch_EmptyColumns_MATLABGemini_AM260316.xlsx';

fprintf('Loading Data... Ensure Excel files are closed!\n');
codes = readvars(consFile, 'Sheet', 'Data', 'Range', 'B5:B270');
names = readvars(consFile, 'Sheet', 'Data', 'Range', 'A5:A270');
%AM260729 Note that in the next 2 lines of code the Excel range needs to be
%         redefined any time the years of range/calculation are modified! 
dataMatrix_Cons = readmatrix(consFile, 'Sheet', 'Data', 'Range', 'AI5:BM270');
dataMatrix_CO2cons  = readmatrix(co2consFile,  'Sheet', 'Data', 'Range', 'AI5:BM270');

years = 1990:2020;
numItems = length(codes);

% Static Bounds
% AM260729 The bounds below, as calculated in the respective STATA world map, need
%          to be changed manually when the code is run to generate GPS1 or GPS2!!!
bounds_Cons = [1499.0, 27447.4];    %bounds_RGDP = [1489, 61606]; -> production-based bounds commented out
bounds_CO2cons  = [0.3, 20.5];      %bounds_CO2prod  = [0.001, 13];
bounds_GPR2cons  = [883.3, 7494.9]; %bounds_GPR2prod = [1401, 16238];

% --- 4. THE LOOP ---
for i = 1:numItems
    isoCode = char(codes(i));
    displayName = char(names(i));
    if isempty(isoCode) || all(isnan(isoCode)), continue; end
    
    fprintf('Processing [%d/%d]: %s (%s)\n', i, numItems, isoCode, displayName);
    
    vec_Cons = dataMatrix_Cons(i, :);
    vec_CO2cons  = dataMatrix_CO2cons(i, :);
    
    % Compute ratio (GPS2 = Consumption / Consumption-based CO2)
    vec_GPR2cons = vec_Cons ./ vec_CO2cons;
    % ANNOTATION: Ensure any non-finite values (Inf, -Inf, or NaN resulting from 
    % division by zero or missing inputs) are strictly converted to NaN.
    vec_GPR2cons(~isfinite(vec_GPR2cons)) = NaN; 
    
    basePath = fullfile(outDir, isoCode);

    draw_and_save(vec_Cons, years, bounds_Cons, wscolors_BlueToRed, ...
        [isoCode ': Real Consumption pc, at constant PPP-USD of 2021, static 2020 winsorization (1990-2020)'], [basePath '_1_RealConspc_STATwin_1990_2020']);
    draw_and_save(vec_CO2cons, years, bounds_CO2cons, wscolors_GreenToBrown, ...
        [isoCode ': Consumption-Based CO2 Emissions pc, in metric tons, static 2020 winsorization (1990-2020)'], [basePath '_2_ConsBasedCO2pc_STATwin_1990_2020']);
    draw_and_save(vec_GPR2cons, years, bounds_GPR2cons, wscolors_BrownToGreen, ...
        [isoCode ': GPS 2, at discounted constant PPP-USD of 2021, static 2020 winsorization (1990-2020)'], [basePath '_3_GPS2ConsBased_STATwin_1990_2020']);
    
    % Summary Figure (Slightly wider to accommodate colorbars)
    fSum = figure('Color','w','Position', [100 100 1050 850], 'Visible', 'off');
    
    s1 = subplot(3,1,1); format_sub(vec_Cons, years, bounds_Cons, wscolors_BlueToRed, 'Real Consumption pc, at constant PPP-USD of 2021, static 2020 winsorization (1990-2020)');
    s2 = subplot(3,1,2); format_sub(vec_CO2cons,  years, bounds_CO2cons,  wscolors_GreenToBrown, 'Consumption-Based CO2 Emissions pc, in metric tons, static 2020 winsorization (1990-2020)');
    s3 = subplot(3,1,3); format_sub(vec_GPR2cons,  years, bounds_GPR2cons,  wscolors_BrownToGreen, 'Greening Prosperity Stripes 2, at discounted constant PPP-USD of 2021, static 2020 winsorization (1990-2020)');
    
    s1.Toolbar.Visible = 'off'; s2.Toolbar.Visible = 'off'; s3.Toolbar.Visible = 'off';
    sgtitle([displayName ' (' isoCode ') - Summary of Stripes'], 'FontWeight','bold');
    
    saveas(fSum, [basePath '_4_SummaryStripes2Cons_STATwin_1990_2020.fig']);
    saveas(fSum, [basePath '_4_SummaryStripes2Cons_STATwin_1990_2020.png']);
    saveas(fSum, [basePath '_4_SummaryStripes2Cons_STATwin_1990_2020.epsc']);
    close(fSum);
    
    if mod(i, 20) == 0, drawnow; end 
end
fprintf('\nDone! All graphs saved in: %s\n', outDir);

toc         % stop the stopwatch timer and display the elapsed time
diary off   % close the diary log and save the text file

%% --- HELPER FUNCTIONS (WITH COLORBARS & TRANSPARENCY FOR MISSING DATA) ---

function draw_and_save(data, years, bounds, cmap, tit, fName)
    % Create a figure with a white background
    f = figure('Color','w','Position',[100 100 850 250],'Visible', 'off'); % Widened for scale
    ax = axes(f);
    
    % ANNOTATION: Force the axes background color to white ('w').
    % This guarantees that any pixel rendered as transparent (due to NaN/missing data)
    % will show as pure white/blank space rather than inheriting default gray axes color.
    set(ax, 'Color', 'w');
    
    % Duplicate the 1xN vector into a 2xN matrix so imagesc can render 2D stripes
    imgData = repmat(data, 2, 1);
    
    % ANNOTATION: Draw the image and capture the returned image handle (hIm).
    % MATLAB's imagesc by default assigns NaN values to the lowest index of the colormap.
    % To prevent NaN years from being rendered with an active color stripe:
    hIm = imagesc(ax, years, [0 1], imgData);
    
    % ANNOTATION: Set the AlphaData (transparency mask) property of the image object.
    % ~isnan(imgData) produces a logical matrix:
    %   - 1 (true) for valid numeric data  -> 100% opaque stripe (colored by colormap)
    %   - 0 (false) for NaN (missing data) -> 100% transparent stripe (shows white background)
    set(hIm, 'AlphaData', ~isnan(imgData));
    
    colormap(ax, cmap); clim(bounds);
    colorbar(ax, 'Location', 'eastoutside'); % ADDED RHS SCALE
    set(ax, 'YTick', [], 'XTick', years(1:1:end), 'FontSize', 9);
    ax.Toolbar.Visible = 'off'; 
    title(tit, 'FontWeight','bold');
    
    saveas(f, [fName '.fig']);
    saveas(f, [fName '.png']);
    saveas(f, [fName '.epsc']);
    close(f);
end

function format_sub(data, years, bounds, cmap, lbl)
    ax = gca;
    
    % ANNOTATION: Set axes background to white for subplot handling of missing data
    set(ax, 'Color', 'w');
    
    % Duplicate the 1xN vector into a 2xN matrix for imagesc
    imgData = repmat(data, 2, 1);
    
    % ANNOTATION: Render image and get graphic handle hIm
    hIm = imagesc(ax, years, [0 1], imgData);
    
    % ANNOTATION: Apply AlphaData transparency mask (~isnan) so missing data (NaN)
    % appears completely white/blank rather than mapped to colormap bounds.
    set(hIm, 'AlphaData', ~isnan(imgData));
    
    colormap(gca, cmap); clim(bounds);
    colorbar(gca, 'Location', 'eastoutside'); % ADDED RHS SCALE
    set(gca, 'YTick', [], 'XTick', years(1:1:end), 'FontSize', 8);
    title(lbl, 'FontWeight','bold');
end