%% GPS2pcConsBased_ExcelTable_GeminiAM260318.m
% First created: AM260316
% Last modified: AM260318

%% MATLAB: Per Capita Calculation (Fixed Header & Alignment)
clear; clc;

% File paths
consFile = 'API_NE.CON.PRVT.PP.KD_DS2_en_excel_v2_5530.xls';
popFile = 'API_SP.POP.TOTL_DS2_en_excel_v2_11.xls';
outFile = 'API_NE.CON.PRVT.PC.PP.KD_MATLAB.xlsx';

fprintf('Reading files... Ensure Excel is closed.\n');

% 1. CONFIGURE IMPORT OPTIONS (EXPLICIT HEADERS VS DATA)
% This prevents the 'Country Name' repetition in row 5.
opts = detectImportOptions(consFile, 'Sheet', 'Data', 'VariableNamingRule', 'preserve');
opts.VariableNamesRange = 'A4'; % Row 4 is ONLY for names
opts.DataRange = 'A5';          % Data starts at Row 5 (Aruba)
T_cons = readtable(consFile, opts);

opts_pop = detectImportOptions(popFile, 'Sheet', 'Data', 'VariableNamingRule', 'preserve');
opts_pop.VariableNamesRange = 'A4';
opts_pop.DataRange = 'A5';
T_pop = readtable(popFile, opts_pop);

% 2. FORCE DATA TYPE CONSISTENCY
% Ensure year columns are numeric (converts cell/string to double)
for i = 5:width(T_cons)
    if iscell(T_cons{:,i})
        T_cons.(i) = str2double(string(T_cons{:,i}));
    end
    if iscell(T_pop{:,i})
        T_pop.(i) = str2double(string(T_pop{:,i}));
    end
end

% 3. ALIGN BY COUNTRY CODE (Preserve Master Order: ABW to ZWE)
% We use ismember to map Population data onto the Consumption table order
[isInPop, locPop] = ismember(T_cons.("Country Code"), T_pop.("Country Code"));

% 4. CALCULATE PER CAPITA (Vectorized)
consData = T_cons{:, 5:end};
popData  = NaN(size(consData)); % Initialize with NaNs
popData(isInPop, :) = T_pop{locPop(isInPop), 5:end};

% Division: Handles zeros or NaNs gracefully
perCapitaMatrix = consData ./ popData;

% 5. CONSTRUCT OUTPUT TABLE
% Start with the 266 rows from the master Consumption table
T_out = T_cons; 
T_out.("Indicator Name")(:) = {'Households consumption expenditure per capita (const. 2021 PPP $)'};
T_out.("Indicator Code")(:) = {'NE.CON.PRVT.PC.PP.KD'};

% Inject the calculated per-capita data
for i = 5:width(T_out)
    T_out.(i) = perCapitaMatrix(:, i-4); 
end

% 6. WRITE TO EXCEL (World Bank Structure: 3 Meta Rows + Header + Data)
% Step A: Read and Write the first 3 metadata rows exactly as they are
metaHeaders = readcell(consFile, 'Sheet', 'Data', 'Range', 'A1:B3');
metaHeaders(cellfun(@(x) any(ismissing(x)), metaHeaders)) = {''};
writecell(metaHeaders, outFile, 'Sheet', 'Data', 'Range', 'A1');

% Step B: Write the table starting at A4
% WriteVariableNames=true ensures Row 4 is the header.
% Data (Aruba) will then follow in Row 5 automatically.
writetable(T_out, outFile, 'Sheet', 'Data', 'Range', 'A4', 'WriteVariableNames', true);

fprintf('Done! Verified Structure:\n');
fprintf(' - Total Rows in Table: %d\n', height(T_out));
fprintf(' - First Country (Row 5): %s (%s)\n', char(T_out.("Country Name")(1)), char(T_out.("Country Code")(1)));
fprintf(' - Last Country (Row 270): %s (%s)\n', char(T_out.("Country Name")(end)), char(T_out.("Country Code")(end)));